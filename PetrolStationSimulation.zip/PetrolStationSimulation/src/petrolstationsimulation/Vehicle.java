
package petrolstationsimulation;



public class Vehicle// this is the node is the queue
{

    int arrivalTime,vehicalNumber,serviceTime;
    Vehicle next;

    Vehicle(int arrivalTime,int vehicleNumber,int serviceTime)
    {
      this.arrivalTime=arrivalTime;
      this.vehicalNumber=vehicleNumber;
      this.serviceTime=serviceTime;
    }

}