
package petrolstationsimulation;


public class MyQueue //singly linkedlist od nodes(Vehicals)
{

 private Vehicle head;
 private Vehicle tail;
 private int sizeOfQueue;

 MyQueue()
 {
   head=null;
   tail=null;
   sizeOfQueue=0;
 }

 public boolean add(Vehicle v)
 {

   if(head==null||tail==null)//queue is empty
   {
     head=tail=v;
   }
   else
   {
     tail.next=v;
     tail=v;
   }

  sizeOfQueue++;
  return true;
 }

 public Vehicle peek()// shows the first element but does not remove it
 {
     return head;
 }

 public Vehicle poll()// shows the first element and removes it from the queue
 {
   Vehicle temp=head;

   if(head!=null)
   {
     head=head.next;
     temp.next=null;
   }

   sizeOfQueue--;
   return temp;
 }

 public int size()
 {
   return sizeOfQueue;
 }

 public Vehicle getTail() 
 {
   return tail;
 }

}