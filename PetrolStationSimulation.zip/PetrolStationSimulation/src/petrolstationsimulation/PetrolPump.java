package petrolstationsimulation;

public class PetrolPump {

    Pump pump1, pump2;
    MyQueue queue;
    float arrivalPercentage;
    float unit3ServiceTimePercentage;
    float unit5ServiceTimePercentage;
    int vehicleCount;
    int maxWaitTime;
    int totalWaitTime;
    int totalServingTime;
    int totalArrivalTimeDifference;
    int simulationTime;
    String Ureport;
    
    PetrolPump(float arrivalPercentage, float unit3ServiceTimePercentage, float unit5ServiceTimePercentage, int simulationTime) {

        pump1 = new Pump("Pump 1");
        pump2 = new Pump("Pump 2");
        queue = new MyQueue();

        totalServingTime = 0;
        totalWaitTime = 0;
        vehicleCount = 0;
        totalArrivalTimeDifference = 0;

        this.arrivalPercentage = arrivalPercentage;
        this.unit3ServiceTimePercentage = unit3ServiceTimePercentage;
        this.unit5ServiceTimePercentage = unit5ServiceTimePercentage;
        this.simulationTime = simulationTime;

    }

    boolean isArriving() {
        if (Math.random() < arrivalPercentage) {
            return true;
        }

        return false;

    }

    boolean is3UnitServiceTime() {
        if (Math.random() < unit3ServiceTimePercentage) {
            return true;
        }

        return false;

    }

    void startSimulation() {

        pump1.openPump();
        pump2.closePump();
         Ureport ="";

        for (int timer = 0; timer < simulationTime; timer++, pump1.incrementTimer(), pump2.incrementTimer()) {

            if (isArriving()) {

                vehicleCount++;
                Ureport += "Vehicle number "+ vehicleCount +" arrived at time unit "+timer +"\n"; 
                  System.out.println("Vehicle number "+ vehicleCount +" arrived at time unit "+timer );
                int serviceTime = (is3UnitServiceTime()) ? 3 : 5;

                Vehicle v = new Vehicle(timer, vehicleCount, serviceTime);

//getting arrival time difference between present vehicle and last added vehicle at queue’s tail

                if (queue.size() > 0) {
                    totalArrivalTimeDifference += (v.arrivalTime - queue.getTail().arrivalTime);
                }

                queue.add(v);

            }

            if (queue.size() == 0) {
                continue;
            }

            if (queue.size() > 2) {
                if (!pump2.isOpen()) {
                    pump2.openPump();
                } else {
                    pump2.closePump();
                }
            }

            if (pump1.isFree()) {

                Vehicle v = queue.poll();
               
                Ureport += "Vehicle  "+ vehicleCount +" served at time unit "+timer+" at pump 1"+"\n"; 
               System.out.println("Vehicle  "+ vehicleCount +" served at time unit "+timer+" at pump 1");
                int waitTime = timer - v.arrivalTime;

                if (waitTime > maxWaitTime) {
                    maxWaitTime = waitTime;
                }

                totalWaitTime += waitTime;

//adding serving time of present vehicle;

                totalServingTime += v.serviceTime;

                pump1.serve(v);

            }

            if (queue.size() == 0) {
                continue;
            }

            if (pump2.isOpen() && pump2.isFree()) {

                Vehicle v = queue.poll();
                 Ureport += "Vehicle  "+ vehicleCount +" served at time unit "+timer+" at pump 2"+"\n"; 
                 System.out.println("Vehicle  "+ vehicleCount +" served at time unit "+timer+" at pump 2");
                int waitTime = timer - v.arrivalTime;

                if (waitTime > maxWaitTime) {
                    maxWaitTime = waitTime;
                }

                totalWaitTime += waitTime;

//adding serving time of present vehicle;

                totalServingTime += v.serviceTime;

                pump2.serve(v);
            }

        }

    }

    void getReport() {

        int numberOfVehiclesServed = pump1.getVehiclesServed() + pump2.getVehiclesServed();
        float ArrivalTimeDifference =  totalArrivalTimeDifference / vehicleCount;

        System.out.println("**Simulation ran for " + simulationTime + " units of time***");
        System.out.println("Average Serving Time:" + totalServingTime / numberOfVehiclesServed);
        System.out.println("Average Arrival Time Difference between Vehicles: " + ArrivalTimeDifference );    
        System.out.println("Longest Time that vehicle waited: " + maxWaitTime);
        System.out.println("Vehicles served at Pump 1: " + pump1.getVehiclesServed());
        System.out.println("Vehicles served at Pump 2: " + pump2.getVehiclesServed());
        System.out.println("Total number of vehicles Arrived: "+ vehicleCount);
        System.out.println("Total number of vehicles served: " + numberOfVehiclesServed);
        System.out.println("Number of vehicles left in queue: " + queue.size());
        System.out.println("Average Wait Time of each vehicle:" + totalWaitTime / numberOfVehiclesServed);

    }

    
     String getUnitReports(){
                    
        return Ureport;
     }
    
    String getSummary() {
        String s = null;
        int numberOfVehiclesServed = pump1.getVehiclesServed() + pump2.getVehiclesServed();
        float ArrivalTimeDifference =  totalArrivalTimeDifference / vehicleCount;

        s = (getUnitReports()+
               "\n" + "**Simulation ran for " + simulationTime + " units of time***"
                + "\n" + "Average Serving Time:" + totalServingTime / numberOfVehiclesServed               
                + "\n" + "Average Arrival Time Difference between Vehicles:" + ArrivalTimeDifference
                + "\n" + "Longest Time that vehicle waited: " + maxWaitTime
                + "\n" + "Vehicles served at Pump 1:" + pump1.getVehiclesServed()
                + "\n" + "Vehicles served at Pump 2: " + pump2.getVehiclesServed()
                + "\n" + "Total number of vehicles Arrived: " +vehicleCount
                + "\n" + "Total number of vehicles served: " + numberOfVehiclesServed
                + "\n" + "Number of vehicles left in queue: " + queue.size()
                + "\n" + "Average Wait Time of each vehicle:" + totalWaitTime / numberOfVehiclesServed
                + "\n");

        return s;


    }
    
    
}