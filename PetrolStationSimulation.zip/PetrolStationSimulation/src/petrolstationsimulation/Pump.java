
package petrolstationsimulation;



public class Pump
{

    private String name;
    private int vehiclesServed;
    private int timer;
    private Vehicle currentVehicle;
    private int startTimeOfCurrentVehicle;
    private boolean free;
    private boolean open;

    Pump(String name)
    {
     this.name=name;
     vehiclesServed=0;
     free=true;
     open=false;
     currentVehicle=null;
     startTimeOfCurrentVehicle=0;
    }

    public void incrementTimer()
    {
      timer++;
    }

    public void serve(Vehicle v)
    {
     currentVehicle=v;
     startTimeOfCurrentVehicle=timer;
    }

    public boolean isFree()
    {
        if(currentVehicle==null){ 
            return free;}
        checkService();
        return free;
    }

    public void checkService()
    {
       if(timer-startTimeOfCurrentVehicle >= currentVehicle.serviceTime)
        {
          vehiclesServed++;
          currentVehicle=null;
          free=true;
        }
       else{ free=false;}
    }

    public void openPump()
    {
        open=true;
    }

    public void closePump()
    {
        open=false;
    }

    public boolean isOpen()
    {
        return open;
    }

    public String getName() 
    {
        return name;
    }

    public int getVehiclesServed()
    {
        return vehiclesServed;
    }

}